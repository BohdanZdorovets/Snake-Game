module org.example {
    requires javafx.controls;
    requires java.sql;
    exports org.example;
}
